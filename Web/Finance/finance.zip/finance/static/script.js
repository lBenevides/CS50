
// alert("A share of {{info["name"]}} ({{info["symbol"]}}) costs ${{info["price"]}}");