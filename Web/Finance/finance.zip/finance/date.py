import datetime

datetime = datetime.datetime.now()
print(datetime)